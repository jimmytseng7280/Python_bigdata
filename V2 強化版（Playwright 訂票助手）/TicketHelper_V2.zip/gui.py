
import tkinter as tk
from tkinter import ttk, messagebox
from scheduler import wait_until
from config import save_config
from browser import open_and_prepare
from login import login
from booking import run_booking

class TicketGUI:

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("訂票助手 V2（Playwright）")
        self.root.geometry("720x520")
        self.build()

    def build(self):

        self.company = tk.StringVar(value="華信")
        self.dep = tk.StringVar(value="TSA")
        self.arr = tk.StringVar(value="KNH")
        self.date = tk.StringVar(value="2026-10-09")
        self.people = tk.IntVar(value=1)
        self.start_time = tk.StringVar(value="2026-07-04 13:30:00")
        self.acc = tk.StringVar()
        self.pwd = tk.StringVar()

        ttk.Label(self.root,text="航空公司").grid(row=0,column=0)
        ttk.Combobox(self.root,textvariable=self.company,values=["華信","立榮"]).grid(row=0,column=1)

        ttk.Label(self.root,text="出發").grid(row=1,column=0)
        ttk.Entry(self.root,textvariable=self.dep).grid(row=1,column=1)

        ttk.Label(self.root,text="目的地").grid(row=2,column=0)
        ttk.Entry(self.root,textvariable=self.arr).grid(row=2,column=1)

        ttk.Label(self.root,text="日期").grid(row=3,column=0)
        ttk.Entry(self.root,textvariable=self.date).grid(row=3,column=1)

        ttk.Label(self.root,text="人數").grid(row=4,column=0)
        ttk.Spinbox(self.root,from_=1,to=9,textvariable=self.people).grid(row=4,column=1)

        ttk.Label(self.root,text="帳號").grid(row=5,column=0)
        ttk.Entry(self.root,textvariable=self.acc).grid(row=5,column=1)

        ttk.Label(self.root,text="密碼").grid(row=6,column=0)
        ttk.Entry(self.root,textvariable=self.pwd,show="*").grid(row=6,column=1)

        ttk.Label(self.root,text="開始時間").grid(row=7,column=0)
        ttk.Entry(self.root,textvariable=self.start_time).grid(row=7,column=1)

        ttk.Button(self.root,text="儲存",command=self.save).grid(row=8,column=0)
        ttk.Button(self.root,text="開始",command=self.start).grid(row=8,column=1)

    def save(self):
        save_config({
            "company":self.company.get(),
            "dep":self.dep.get(),
            "arr":self.arr.get(),
            "date":self.date.get(),
            "people":self.people.get()
        })
        messagebox.showinfo("OK","已儲存")

    def start(self):

        def job():

            info = {
                "company":self.company.get(),
                "dep":self.dep.get(),
                "arr":self.arr.get(),
                "date":self.date.get(),
                "people":self.people.get()
            }

            login(self.acc.get(), self.pwd.get())

            p,b,page = open_and_prepare(info["company"])

            run_booking(p,b,page,info)

        wait_until(self.start_time.get(), job)
        messagebox.showinfo("已啟動","等待開賣時間")

    def run(self):
        self.root.mainloop()
