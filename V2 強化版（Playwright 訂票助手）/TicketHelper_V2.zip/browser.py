
from playwright.sync_api import sync_playwright

def open_and_prepare(company):
    p = sync_playwright().start()
    browser = p.chromium.launch(headless=False)
    page = browser.new_page()

    if company == "華信":
        page.goto("https://www.mandarin-airlines.com")
    else:
        page.goto("https://www.uniair.com.tw")

    return p, browser, page


def fill_form(page, info):
    # ⚠️ 示意：不包含自動送出
    print("開始填寫（示意）")

    # 因網站會變動，這裡用通用方式示範
    page.wait_for_timeout(1000)

    try:
        # 這裡不綁死 selector，避免違規與失效
        page.keyboard.type(info["dep"])
        page.keyboard.press("Tab")
        page.keyboard.type(info["arr"])
        page.keyboard.press("Tab")
        page.keyboard.type(info["date"])
    except:
        pass

    print("填寫完成，等待使用者確認")
